----------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE PR_LOG (v_file VARCHAR2,V_LINE VARCHAR2) IS
	  f UTL_FILE.FILE_TYPE;
  	  fname VARCHAR2(255);
  BEGIN
	IF v_line IS NOT NULL THEN
   	   f := UTL_FILE.FOPEN ('LOGS', v_file || '.txt', 'A');
   	   UTL_FILE.PUT_LINE(f, v_line);
	   UTL_FILE.FCLOSE(f);
    END IF;
  END;
/
----------------------------------------------------------------------------
BEGIN
PR_LOG('Logs', 'Creating table DOCUMENTS');
END;
/
----------------------------------------------------------------------------
CREATE TABLE DOCUMENTS
(
    Document_Id NUMBER NOT NULL,
    Document_Name VARCHAR2(50) NOT NULL,
    Document_Description CLOB,
    Record_Timestamp DATE NOT NULL,
    Timestamp DATE NOT NULL,
    Record_User_Id VARCHAR2(50) NOT NULL,
    User_Id VARCHAR2(50) NOT NULL,
    CONSTRAINT Document_pk PRIMARY KEY(Document_id)
);
/
----------------------------------------------------------------------------
BEGIN
PR_LOG('Logs', 'Creating sequence');
END;
/
----------------------------------------------------------------------------
CREATE SEQUENCE Document_Id_SEQ INCREMENT BY 1 START WITH 1 NOCYCLE NOCACHE NOORDER;
/
----------------------------------------------------------------------------
BEGIN
PR_LOG('Logs', 'Inserting data into table DOCUMENTS');
END;
/
----------------------------------------------------------------------------
INSERT ALL
    INTO DOCUMENTS(Document_Id, Document_Name, Document_Description, Record_Timestamp, Timestamp, Record_User_Id, User_id)
    VALUES (Document_Id_SEQ.NEXTVAL, 'DOCUMENT1', 'This is document 1', SYSDATE, SYSDATE-1, 1, 1)
    INTO DOCUMENTS(Document_Id, Document_Name, Document_Description, Record_Timestamp, Timestamp, Record_User_Id, User_id)
    VALUES (Document_Id_SEQ.NEXTVAL, 'DOCUMENT2', 'This is document 2', SYSDATE, SYSDATE-2, 2, 2)
    INTO DOCUMENTS(Document_Id, Document_Name, Document_Description, Record_Timestamp, Timestamp, Record_User_Id, User_id)
    VALUES (Document_Id_SEQ.NEXTVAL, 'DOCUMENT3', 'This is document 3', SYSDATE, SYSDATE-3, 3, 3)
SELECT * FROM DUAL;
/
----------------------------------------------------------------------------
BEGIN
PR_LOG('Logs', 'Creating package TEST_PACKAGE');
END;
/
----------------------------------------------------------------------------
CREATE OR REPLACE PACKAGE TEST_PACKAGE IS

PROCEDURE print_documents;

FUNCTION validate_pesel(p_pesel VARCHAR2)
RETURN BOOLEAN;

END;
/
----------------------------------------------------------------------------
BEGIN
PR_LOG('Logs', 'Creating package body TEST_PACKAGE');
END;
/
----------------------------------------------------------------------------
CREATE OR REPLACE PACKAGE BODY TEST_PACKAGE 
IS

PROCEDURE print_documents
IS
    CURSOR c_documents
    IS
    SELECT Document_Description
    FROM DOCUMENTS;
BEGIN
    IF c_documents%ISOPEN THEN
        CLOSE c_documents;
    END IF;
    
    FOR record IN c_documents
    LOOP
        IF record.Document_Description IS NULL THEN
            DBMS_OUTPUT.PUT_LINE('No Description');
        ELSE
           DBMS_OUTPUT.PUT_LINE(record.Document_Description);
        END IF;
    END LOOP;
END;

FUNCTION validate_pesel(p_pesel VARCHAR2)
RETURN BOOLEAN
IS
TYPE numbers IS VARRAY(11) OF SIMPLE_INTEGER;
    v_numbers numbers := numbers(1, 3, 7, 9, 1, 3, 7,9,1,3,1);
    n_sum NUMBER := 0;
BEGIN
    IF LENGTH(p_pesel) != 11 THEN
        RETURN FALSE;
    END IF;
    FOR i IN 1..v_numbers.COUNT
        LOOP
            n_sum := n_sum + TO_NUMBER(SUBSTR( p_pesel, i,1)) * v_numbers(i);
        END LOOP;
    IF MOD(n_sum, 10) = 0 THEN
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RETURN FALSE;
END;

END;
/
----------------------------------------------------------------------------
BEGIN
PR_LOG('Logs', 'Creating package IMPORT_DATA');
END;
/
----------------------------------------------------------------------------
CREATE OR REPLACE PACKAGE IMPORT_DATA IS

PROCEDURE F_IMPORT_DATA(p_name_of_file VARCHAR2, p_folder VARCHAR2);

END;
/

----------------------------------------------------------------------------
BEGIN
PR_LOG('Logs', 'Creating package body IMPORT_DATA');
END;
/
----------------------------------------------------------------------------
CREATE OR REPLACE PACKAGE BODY IMPORT_DATA IS

RESULT BOOLEAN;
PROCEDURE F_IMPORT_DATA(v_file VARCHAR2, v_directory VARCHAR2)
IS
l_file UTL_FILE.FILE_TYPE;
l_text varchar2(32767);
text varchar2(32767);
BEGIN
    l_file := utl_file.fopen(v_directory, v_file, 'R', 32767);
    
    LOOP
       utl_file.get_line(l_file, l_text, 32767); 

       INSERT INTO DOCUMENTS(Document_Id, Document_Name, Document_Description, Record_Timestamp, Timestamp, Record_User_Id, User_id)
       VALUES   (TO_NUMBER(REGEXP_SUBSTR(l_text, '[^,]+', 1, 1)),
                 REGEXP_SUBSTR(l_text, '[^,]+', 1, 2),
                 REGEXP_SUBSTR(l_text, '[^,]+', 1, 3),
                 TO_DATE(REGEXP_SUBSTR(l_text, '[^,]+', 1, 4), 'YYYY-MM-DD'),
                 TO_DATE(REGEXP_SUBSTR(l_text, '[^,]+', 1, 5), 'YYYY-MM-DD'),
                 TO_NUMBER(REGEXP_SUBSTR(l_text, '[^,]+', 1, 6)),
                 TO_NUMBER(REGEXP_SUBSTR(l_text, '[^,]+', 1, 7))
                );    
     END LOOP;

    utl_file.fclose(l_file);
    DBMS_OUTPUT.PUT_LINE('OK');
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('NO DATA FOUND');
    WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('NO OK');
END;
END;
/
----------------------------------------------------------------------------